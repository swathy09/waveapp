var mongoose=require("mongoose");
var Schema=mongoose.Schema;

var wave=new Schema({
  Batch_Name:String,
  Batch_Type:String,
  Location:String,
  Participants:String,
  Planned_sDate:String,
  Planned_eDate:String,
  Actual_sDate:String,
  Actual_eDate:String,
  Parti_passed:String,
});

module.exports= mongoose.model('wave',wave);
