var express = require('express');
var router = express.Router();
var w=require('../model/wave');
var mongoose=require('mongoose');

router.post('/add', function(req, res, next){

  var wave=new w()
    wave.Batch_Name=req.body.Batch_Name;
    wave.Batch_Type=req.body.Batch_Type;
    wave.Location=req.body.Location;
    wave.Participant=req.body.Participant;
    wave.Planned_sDate=req.body.Planned_sDate;
    wave.Planned_eDate=req.body.Planned_eDate;
    console.log(wave);
    wave.save(function(err){
      if(err)
      {
        res.send(err);
      }
      else
      {
          res.send("Data Inserted");
      }
    });
});

router.get('/display', function(req, res, next) {

  w.find({},function(err,docs){
    if(docs){
      res.json(docs);
    }
    else {
      res.send("error in display");
    }
  });
});

// router.put('/update', function(req, res, next){
//
//   var name=req.body;
//   m.findOneAndUpdate({imdbID : req.body.imdbID},name,function(err){
//     if(err)
//     {
//       res.send(err);
//     }
//     res.send("wave Updated");
//   });
// });
//
// router.delete('/delete', function(req, res, next){
//
//   m.findOneAndRemove({
//     imdbID : req.body.imdbID
//   },function(err){
//     if(err)
//     {
//       res.send(err);
//     }
//     res.send("wave Deleted");
//   });
// });

module.exports = router;
