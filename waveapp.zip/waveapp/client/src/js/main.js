var React=require('react');
var ReactDOM=require('react-dom');
var { browserHistory,hashHistory, Route, Router, IndexRoute }=require('react-router');
var Home=require('./component/Home');
var Navbar=require('./component/Navbar');
var DataEntry=require('./component/DataEntry');
var ViewBatch=require('./component/ViewBatch');

var MainComp=React.createClass({
  render:function()
  {
    return(
      <div>
      <Navbar />
      {this.props.children}
      </div>
    );
  }});

ReactDOM.render(
  <Router history={browserHistory}>
      <Route path="/" component={MainComp} >
       <IndexRoute component={Home} />
       <Route path="/home" component={Home} />
       <Route path="/dataentry" component={DataEntry} />
       <Route path="/viewbatch" component={ViewBatch} />
      </Route>
      {/*Comment*/}
  </Router>,document.getElementById('app'));
