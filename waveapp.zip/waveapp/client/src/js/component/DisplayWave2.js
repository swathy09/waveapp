var React=require('react');
var ReactDOM=require('react-dom');
var $=require('../vendor/jquery');
var x="";
var DisplayWave2=React.createClass({

render:function(){

  return(
    <div className="content">
      <div>{this.props.object.Batch_Name}</div>
      <div>{this.props.object.Batch_Type}</div>
      <div>{this.props.object.Location}</div>
      <div>{this.props.object.Participant}</div>
      <div>{this.props.object.Planned_sDate}</div>
      <div>{this.props.object.Planned_eDate}</div>

    </div>
  );
  }
});

module.exports=DisplayWave2;
