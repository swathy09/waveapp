var React= require('react');
var DisplayWave1=require('./DisplayWave1');
var $=require('../vendor/jquery');

var ViewBatch=React.createClass({

  getInitialState : function()
  {
   return({data :[]});
  },

  componentDidMount : function()
  {
    $.ajax({
    type : 'GET',
   	cache:false,
   	dataType:'json',
    url:'http://localhost:8080/wave/display' ,
   	success:function(data1){
   	  this.setState({data:data1});
   	}.bind(this),
 });
 },

 render:function(){
 	return(
 		<DisplayWave1 values={this.state.data} />
 	);
 }
});
module.exports=ViewBatch;
