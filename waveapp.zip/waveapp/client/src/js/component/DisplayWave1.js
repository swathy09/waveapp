var React=require('react');
var DisplayWave2= require('./DisplayWave2');

//mapping data to child
 var DisplayWave1=React.createClass({
 render:function()
 {
 	var waves=this.props.values.map(function(value){
 	return(
 		<DisplayWave2 object={value} />
 	);
 });

 return(
 <div>
 	{waves}
 </div>
 );

 }
 });
module.exports=DisplayWave1;
