var React=require('react');
var ReactDOM=require('react-dom');
var bname="";
var bType="";
var loc="";
var participant="";
var sDate="";
var eDate="";
var data=[];

var DataEntry=React.createClass({

  first:function(event)
  {
    bName=event.target.value;
  },

  second:function(event)
  {
    bType=event.target.value;
  },

  third:function(event)
  {
    loc=event.target.value;
  },

  fourth:function(event)
  {
    participant=event.target.value;
  },

  fifth:function(event)
  {
    sDate=event.target.value;
  },

  sixth:function(event)
  {
    eDate=event.target.value;
  },

  handleClick:function()
  {
    var obj1={};
    obj1["Batch_Name"]=bName;
    obj1["Batch_Type"]=bType;
    obj1["Location"]=loc;
    obj1["Participants"]=participant;
    obj1["Planned_sDate"]=sDate;
    obj1["Planned_eDate"]=eDate;
    console.log(obj1);
    data=obj1;

    $.ajax({
    type : 'POST',
   	cache:false,
   	dataType:'json',
    data: data,
    url:'http://localhost:8080/wave/add' ,
   	success:function(data){
      console.log(data);
   	}.bind(this),
    error:function(xhr,status,err){
      this.setState({data:this.props.obj});
      console.error(this.props.url,status,err.toString());
    }.bind(this)
   });
  },

  render:function()
  {
  return(

      <div >
        Batch Name: <input type="text" onChange={this.first}  /><br /><br />
        Batch type: <input type="text" onChange={this.second} /><br /><br />
        Location: <input type="text" onChange={this.third}  /><br /><br />
        Number of Participant: <input type="text" onChange={this.fourth}  /><br /><br />
        Planned Start Date: <input type="Date" onChange={this.fifth}  /><br /><br />
        Planned End Date: <input type="Date" onChange={this.sixth}  /><br /><br />
        <button type="button" className="btn btn-info" onClick={this.handleClick}>Submit</button>
      </div>
  );
  }
});

module.exports=DataEntry;
